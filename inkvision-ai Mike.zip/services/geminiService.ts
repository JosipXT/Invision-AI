import { GoogleGenAI, Modality } from "@google/genai";

export const generateTattooPreview = async (
  compositedImageBase64: string,
  tattooPromptDetail: string,
  selectedColor: string
): Promise<string> => {
  
  if (!process.env.API_KEY) {
    throw new Error("API Key not found");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Clean base64 string if it has headers
  const cleanBase64 = compositedImageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

  const colorInstruction = selectedColor !== '#000000' 
    ? `La tinta del diseño debe verse de color ${selectedColor}.` 
    : `La tinta debe ser negra.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType: 'image/jpeg',
            },
          },
          {
            text: `Actúa como un motor de renderizado físico ultra realista.
            
            Tienes una imagen de entrada que consiste en un diseño gráfico 2D superpuesto digitalmente sobre una foto de piel real.
            
            TU OBJETIVO:
            Fusionar el diseño gráfico superpuesto en la piel para que parezca un tatuaje real ya curado, PERO MANTENIENDO EL DISEÑO VISUAL EXACTO AL 100%.
            
            REGLAS CRÍTICAS (NO ROMPER):
            1. FIDELIDAD ABSOLUTA AL DISEÑO: NO redibujes, NO inventes, NO cambies el estilo, NO agregues detalles que no existen en el gráfico superpuesto. El contorno y la forma interna deben ser IDÉNTICOS pixel a pixel a la superposición.
            2. Si el diseño superpuesto es un dragón específico, DEBE SER ESE MISMO DRAGÓN EXACTO, no otro dragón genérico.
            3. Solo debes manipular la TEXTURA y la ILUMINACIÓN. Haz que las líneas negras planas parezcan tinta inyectada bajo la epidermis.
            4. Añade imperfecciones de la piel (poros, vello, textura) ENCIMA del diseño para integrarlo.
            5. Aplica la iluminación de la foto original sobre el diseño (brillos, sombras del cuerpo).
            6. Elimina los bordes blancos o el "recuadro" si el diseño original no tenía fondo transparente, haciendo que solo quede la tinta.
            
            Contexto del diseño (SOLO PARA REFERENCIA DE MATERIAL, NO PARA CAMBIAR LA FORMA): ${tattooPromptDetail}.
            ${colorInstruction}
            
            Genera solo la imagen resultante final.`,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    // Extract image from response
    const part = response.candidates?.[0]?.content?.parts?.[0];
    
    if (part && part.inlineData && part.inlineData.data) {
      return `data:image/png;base64,${part.inlineData.data}`;
    } else {
      throw new Error("No image data received from Gemini.");
    }

  } catch (error: any) {
    console.error("Gemini Service Error:", error);
    throw new Error(error.message || "Failed to generate tattoo preview.");
  }
};