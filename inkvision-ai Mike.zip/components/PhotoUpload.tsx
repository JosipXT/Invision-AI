import React, { useCallback, useState } from 'react';
import { UploadCloud, Image as ImageIcon, X } from 'lucide-react';

interface PhotoUploadProps {
  onImageSelected: (base64: string) => void;
  onClear: () => void;
  currentImage: string | null;
}

export const PhotoUpload: React.FC<PhotoUploadProps> = ({ onImageSelected, onClear, currentImage }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) return;
    
    const reader = new FileReader();
    reader.onloadend = () => {
      onImageSelected(reader.result as string);
    };
    reader.readAsDataURL(file);
  }, [onImageSelected]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, [handleFile]);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  if (currentImage) {
    return (
      <div className="relative w-full max-w-md mx-auto group">
        <img 
          src={currentImage} 
          alt="Preview" 
          className="w-full h-64 object-cover rounded-xl border-2 border-gold-500/50 shadow-xl"
        />
        <button 
          onClick={onClear}
          className="absolute -top-3 -right-3 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 shadow-lg transition-transform hover:scale-110"
        >
          <X size={20} />
        </button>
      </div>
    );
  }

  return (
    <div className="w-full max-w-lg mx-auto">
      <label
        onDrop={onDrop}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        className={`
          flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-xl cursor-pointer transition-all duration-300
          ${isDragging 
            ? 'border-gold-500 bg-ink-800/80 scale-105 shadow-[0_0_30px_rgba(245,158,11,0.2)]' 
            : 'border-ink-600 bg-ink-800/30 hover:bg-ink-800/50 hover:border-ink-500'
          }
        `}
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center p-4">
          <div className={`mb-4 p-4 rounded-full ${isDragging ? 'bg-gold-500 text-black' : 'bg-ink-700 text-gray-400'}`}>
            {isDragging ? <UploadCloud size={32} /> : <ImageIcon size={32} />}
          </div>
          <p className="mb-2 text-lg font-semibold text-gray-300">
            {isDragging ? '¡Suelta la foto aquí!' : 'Haz clic o arrastra tu foto'}
          </p>
          <p className="text-sm text-gray-500">
            Sube una foto clara de la zona del cuerpo (PNG, JPG)
          </p>
        </div>
        <input 
          type="file" 
          className="hidden" 
          accept="image/*"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} 
        />
      </label>
    </div>
  );
};