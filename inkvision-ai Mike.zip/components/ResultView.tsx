import React, { useState } from 'react';
import { Download, RefreshCw, Share2, Save } from 'lucide-react';
import { Button } from './ui/Button';
import { TATTOO_DESIGNS } from '../constants';
import { SavedTattoo } from '../types';

interface ResultViewProps {
  resultImage: string;
  selectedTattooId: string | null;
  onReset: () => void;
}

export const ResultView: React.FC<ResultViewProps> = ({ resultImage, selectedTattooId, onReset }) => {
  const [isSaved, setIsSaved] = useState(false);
  
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = resultImage;
    link.download = 'inkvision-preview.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveToGallery = () => {
    if (isSaved) return;
    
    const design = TATTOO_DESIGNS.find(d => d.id === selectedTattooId);
    const newItem: SavedTattoo = {
      id: crypto.randomUUID(),
      date: Date.now(),
      image: resultImage,
      designName: design?.name || 'Tatuaje Personalizado'
    };

    const existing = localStorage.getItem('inkvision_gallery');
    const gallery: SavedTattoo[] = existing ? JSON.parse(existing) : [];
    gallery.push(newItem);
    localStorage.setItem('inkvision_gallery', JSON.stringify(gallery));
    
    setIsSaved(true);
  };

  const handleShare = async () => {
    try {
      // Convert base64 to blob for sharing
      const res = await fetch(resultImage);
      const blob = await res.blob();
      const file = new File([blob], 'tattoo-preview.png', { type: 'image/png' });

      if (navigator.share) {
        await navigator.share({
          title: 'Mi diseño en InkVision AI',
          text: '¡Mira cómo me quedaría este tatuaje!',
          files: [file]
        });
      } else {
        alert('Tu navegador no soporta compartir nativamente. Puedes descargar la imagen.');
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col items-center animate-in fade-in duration-700">
      <h2 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-gold-400 to-orange-500 mb-8 text-center">
        ¡Tu Tatuaje Está Listo!
      </h2>
      
      <div className="relative group w-full max-w-md rounded-2xl overflow-hidden border-2 border-ink-600 shadow-2xl bg-ink-900 mb-8">
        <img 
          src={resultImage} 
          alt="Resultado Tatuaje" 
          className="w-full h-auto object-contain"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-lg px-4">
        <Button onClick={handleDownload} variant="secondary" className="w-full">
          <Download size={20} /> Guardar en Disp.
        </Button>
        
        <Button onClick={handleSaveToGallery} variant={isSaved ? "outline" : "primary"} disabled={isSaved} className="w-full">
          {isSaved ? <><Save size={20} /> Guardado</> : <><Save size={20} /> Guardar en Galería</>}
        </Button>

        <Button onClick={handleShare} variant="outline" className="w-full">
          <Share2 size={20} /> Compartir
        </Button>

        <Button onClick={onReset} variant="outline" className="w-full border-dashed">
          <RefreshCw size={20} /> Probar Otro
        </Button>
      </div>
    </div>
  );
};