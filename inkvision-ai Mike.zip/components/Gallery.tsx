import React, { useEffect, useState } from 'react';
import { SavedTattoo } from '../types';
import { Trash2, Calendar, ChevronLeft, ImageOff } from 'lucide-react';

interface GalleryProps {
  onClose: () => void;
}

export const Gallery: React.FC<GalleryProps> = ({ onClose }) => {
  const [savedTattoos, setSavedTattoos] = useState<SavedTattoo[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('inkvision_gallery');
    if (saved) {
      try {
        setSavedTattoos(JSON.parse(saved).reverse()); // Newest first
      } catch (e) {
        console.error("Failed to parse gallery", e);
      }
    }
  }, []);

  const handleDelete = (id: string) => {
    const updated = savedTattoos.filter(t => t.id !== id);
    setSavedTattoos(updated);
    localStorage.setItem('inkvision_gallery', JSON.stringify(updated));
  };

  return (
    <div className="w-full flex flex-col items-center animate-in slide-in-from-bottom-10 duration-500 min-h-[50vh]">
      <div className="w-full max-w-5xl flex items-center justify-between mb-8">
        <button 
            onClick={onClose}
            className="flex items-center gap-2 text-gray-400 hover:text-gold-500 transition-colors"
        >
            <ChevronLeft size={20} /> Volver
        </button>
        <h1 className="text-3xl font-bold text-white">Mi Galería</h1>
        <div className="w-20"></div> {/* Spacer for centering */}
      </div>

      {savedTattoos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <ImageOff size={64} className="mb-4 opacity-50" />
          <p className="text-xl">Aún no has guardado ningún diseño.</p>
          <p className="text-sm mt-2">Crea tu primer tatuaje para verlo aquí.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-5xl">
          {savedTattoos.map((item) => (
            <div key={item.id} className="bg-ink-800 rounded-xl overflow-hidden border border-ink-700 shadow-lg group">
              <div className="relative aspect-[3/4]">
                <img 
                    src={item.image} 
                    alt={item.designName} 
                    className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="self-end bg-red-500/80 text-white p-2 rounded-full hover:bg-red-600 mb-auto transition-transform hover:scale-110"
                  >
                    <Trash2 size={18} />
                  </button>
                  
                  <button 
                    onClick={() => {
                        const link = document.createElement('a');
                        link.href = item.image;
                        link.download = `tattoo-${item.designName}-${item.date}.png`;
                        link.click();
                    }}
                    className="w-full py-2 bg-gold-500 text-black font-bold rounded-lg mt-4 hover:bg-gold-400"
                  >
                    Descargar
                  </button>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-white text-lg">{item.designName}</h3>
                <div className="flex items-center gap-2 text-gray-500 text-xs mt-1">
                  <Calendar size={12} />
                  {new Date(item.date).toLocaleDateString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};