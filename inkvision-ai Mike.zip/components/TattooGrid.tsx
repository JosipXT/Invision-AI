
import React from 'react';
import { TATTOO_DESIGNS } from '../constants';
import { CheckCircle } from 'lucide-react';

interface TattooGridProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export const TattooGrid: React.FC<TattooGridProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 w-full max-w-6xl px-4">
      {TATTOO_DESIGNS.map((design) => {
        const isSelected = selectedId === design.id;

        return (
          <div
            key={design.id}
            onClick={() => onSelect(design.id)}
            className={`
              relative group cursor-pointer rounded-2xl overflow-hidden border-2 transition-all duration-300
              flex flex-col aspect-[3/4] bg-ink-800
              ${isSelected 
                ? 'border-gold-500 shadow-[0_0_25px_rgba(245,158,11,0.3)] scale-105 z-10 ring-2 ring-gold-500/50' 
                : 'border-ink-700 hover:border-ink-500 hover:shadow-lg'
              }
            `}
          >
            {/* Image Container - White background to simulate flash paper */}
            <div className="flex-grow w-full relative bg-white p-4 flex items-center justify-center overflow-hidden">
                <img 
                    src={design.imageSrc} 
                    alt={design.name}
                    // Use user provided links. Since they might be viewer links in the constants, 
                    // in a real scenario they might break without direct linking.
                    // We add a fallback just in case for the UI demo.
                    onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://placehold.co/400x600/white/black?text=${encodeURIComponent(design.name)}`;
                    }}
                    className={`
                        w-full h-full object-contain transition-transform duration-500
                        ${isSelected ? 'scale-110' : 'group-hover:scale-105'}
                    `}
                />
                
                {isSelected && (
                    <div className="absolute top-4 right-4 bg-gold-500 rounded-full p-1 shadow-lg animate-in fade-in zoom-in">
                        <CheckCircle size={24} className="text-ink-900" />
                    </div>
                )}
            </div>

            {/* Info Container */}
            <div className={`
              p-4 transition-colors duration-300
              ${isSelected ? 'bg-ink-800' : 'bg-ink-900'}
            `}>
              <div className="flex justify-between items-start mb-1">
                  <h3 className={`text-lg font-bold ${isSelected ? 'text-gold-400' : 'text-white'}`}>
                    {design.name}
                  </h3>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-ink-700 text-gray-300 px-2 py-1 rounded">
                    {design.style}
                  </span>
              </div>
              <p className="text-sm text-gray-400 leading-snug line-clamp-2">
                {design.description}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
};
