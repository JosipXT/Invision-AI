import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/Button';
import { TATTOO_DESIGNS } from '../constants';
import { 
  RotateCw, ZoomIn, Palette, Check, RotateCcw, Move
} from 'lucide-react';

interface TattooEditorProps {
  userImage: string;
  selectedTattooId: string;
  onGenerate: (compositedImage: string, selectedColor: string) => void;
  onCancel: () => void;
}

export const TattooEditor: React.FC<TattooEditorProps> = ({ 
  userImage, 
  selectedTattooId, 
  onGenerate,
  onCancel
}) => {
  const design = TATTOO_DESIGNS.find(d => d.id === selectedTattooId);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 50, y: 50 }); // Percentage
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [color, setColor] = useState('#000000');
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Reset when design changes
  useEffect(() => {
    setPosition({ x: 50, y: 50 });
    setScale(1);
    setRotation(0);
  }, [selectedTattooId]);

  // Handle Dragging
  const handlePointerDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const deltaX = e.clientX - dragStart.x;
    const deltaY = e.clientY - dragStart.y;

    const percentX = (deltaX / rect.width) * 100;
    const percentY = (deltaY / rect.height) * 100;

    setPosition(prev => ({
      x: Math.max(0, Math.min(100, prev.x + percentX)),
      y: Math.max(0, Math.min(100, prev.y + percentY))
    }));

    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
  };

  const handleSaveComposite = async () => {
    if (!containerRef.current || !design) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const bgImg = new Image();
    const tattooImg = new Image();

    // Load both images
    const loadImages = Promise.all([
        new Promise((resolve) => { bgImg.onload = resolve; bgImg.src = userImage; }),
        new Promise((resolve) => { tattooImg.crossOrigin = "Anonymous"; tattooImg.onload = resolve; tattooImg.src = design.imageSrc; })
    ]);

    await loadImages;

    canvas.width = bgImg.naturalWidth;
    canvas.height = bgImg.naturalHeight;
    
    if (ctx) {
        // 1. Draw Body Photo
        ctx.drawImage(bgImg, 0, 0);

        // 2. Calculate Tattoo Position
        const x = (position.x / 100) * canvas.width;
        const y = (position.y / 100) * canvas.height;
        
        // Base size relative to canvas (e.g., 30% of width)
        const baseSize = Math.min(canvas.width, canvas.height) * 0.3;
        const width = baseSize * scale;
        // Maintain aspect ratio
        const aspectRatio = tattooImg.naturalWidth / tattooImg.naturalHeight;
        const height = width / aspectRatio;

        ctx.save();
        ctx.translate(x, y);
        ctx.rotate((rotation * Math.PI) / 180);
        
        // Draw raw tattoo image (AI handles blending/color better than canvas manipulation)
        // We draw it centered
        ctx.drawImage(tattooImg, -width / 2, -height / 2, width, height);
        
        ctx.restore();
        
        // 3. Export
        onGenerate(canvas.toDataURL('image/jpeg', 0.9), color);
    }
  };

  // Helper to estimate CSS filter for preview (simple coloring)
  // In a real app, this would use a complex solver. Here we use mix-blend-mode or mask-image
  const getPreviewStyle = () => {
    // If black ink (#000000), standard. 
    // For colors, we can use mask-image if it's a transparent PNG, 
    // or just pass the raw image and let the AI do the heavy lifting for the final result.
    // For this UI, let's use a simple filter for visual feedback if it's not black.
    
    // NOTE: Changing color of a raster image in CSS without mask is tricky. 
    // We will use mask-image which is robust for transparent PNGs.
    if (color !== '#000000') {
        return {
            maskImage: `url(${design?.imageSrc})`,
            maskSize: 'contain',
            maskRepeat: 'no-repeat',
            maskPosition: 'center',
            backgroundColor: color,
            // Standard image hidden, background color shown through mask
        };
    }
    return {};
  };

  return (
    <div className="w-full flex flex-col items-center gap-6 animate-in fade-in">
        <div className="flex items-center justify-between w-full max-w-2xl mb-2">
            <h2 className="text-2xl font-bold text-white">Ajusta tu Tatuaje</h2>
            <button onClick={onCancel} className="text-gray-400 hover:text-white underline text-sm">Cancelar</button>
        </div>

        <div className="text-sm text-gray-400 mb-2 bg-ink-800 px-4 py-2 rounded-full flex items-center gap-2">
            <Move size={14} /> Arrastra para mover el diseño sobre tu piel
        </div>

        {/* Editor Canvas */}
        <div 
            ref={containerRef}
            className="relative w-full max-w-md aspect-[3/4] bg-black rounded-xl overflow-hidden border-2 border-ink-600 shadow-2xl touch-none cursor-crosshair"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
        >
            <img 
                src={userImage} 
                alt="Background" 
                className="w-full h-full object-cover pointer-events-none select-none" 
            />
            
            {/* Overlay Tattoo */}
            {design && (
                <div 
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 origin-center pointer-events-none"
                    style={{
                        left: `${position.x}%`,
                        top: `${position.y}%`,
                        width: `${30 * scale}%`, 
                        transform: `translate(-50%, -50%) rotate(${rotation}deg)`
                    }}
                >
                    {color === '#000000' ? (
                        <img 
                            src={design.imageSrc}
                            alt="tattoo"
                            className="w-full h-auto drop-shadow-2xl filter mix-blend-multiply"
                            style={{ opacity: 0.9 }}
                        />
                    ) : (
                        // Color Mode: Use mask to create a solid color shape matching the image
                        <div 
                            className="w-full aspect-square"
                            style={{
                                maskImage: `url(${design.imageSrc})`,
                                WebkitMaskImage: `url(${design.imageSrc})`,
                                maskSize: 'contain',
                                WebkitMaskSize: 'contain',
                                maskRepeat: 'no-repeat',
                                WebkitMaskRepeat: 'no-repeat',
                                maskPosition: 'center',
                                WebkitMaskPosition: 'center',
                                backgroundColor: color,
                                opacity: 0.85,
                                mixBlendMode: 'multiply' // Helps it look like ink on skin
                            }}
                        />
                    )}
                    
                    {/* Bounding Box Guide (Visible when dragging or default) */}
                    <div className={`absolute -inset-2 border-2 border-dashed border-gold-500/60 rounded-lg transition-opacity duration-200 ${isDragging ? 'opacity-100' : 'opacity-30'}`} />
                </div>
            )}
        </div>

        {/* Controls */}
        <div className="w-full max-w-md space-y-4 bg-ink-800/80 backdrop-blur-sm p-6 rounded-xl border border-ink-700">
            <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                    <label className="flex items-center text-sm text-gray-300 gap-2 font-medium">
                        <ZoomIn size={16} className="text-gold-500" /> Tamaño
                    </label>
                    <input 
                        type="range" 
                        min="0.5" 
                        max="3" 
                        step="0.1" 
                        value={scale}
                        onChange={(e) => setScale(parseFloat(e.target.value))}
                        className="w-full h-2 bg-ink-600 rounded-lg appearance-none cursor-pointer accent-gold-500 hover:accent-gold-400"
                    />
                </div>

                <div className="space-y-2">
                    <label className="flex items-center text-sm text-gray-300 gap-2 font-medium">
                        <RotateCw size={16} className="text-gold-500" /> Rotación
                    </label>
                    <input 
                        type="range" 
                        min="0" 
                        max="360" 
                        value={rotation}
                        onChange={(e) => setRotation(parseInt(e.target.value))}
                        className="w-full h-2 bg-ink-600 rounded-lg appearance-none cursor-pointer accent-gold-500 hover:accent-gold-400"
                    />
                </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-ink-700">
                <label className="flex items-center text-sm text-gray-300 gap-2 font-medium">
                    <Palette size={16} className="text-gold-500" /> Color de Tinta
                </label>
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin">
                    {[
                        '#000000', // Black
                        '#1F2937', // Charcoal
                        '#7F1D1D', // Red
                        '#1E3A8A', // Blue
                        '#064E3B', // Green
                        '#D97706', // Amber
                        '#581c87', // Purple
                    ].map((c) => (
                        <button
                            key={c}
                            onClick={() => setColor(c)}
                            className={`w-10 h-10 rounded-full border-2 flex-shrink-0 transition-transform ${color === c ? 'border-gold-500 scale-110 ring-2 ring-gold-500/30' : 'border-transparent hover:scale-105'}`}
                            style={{ backgroundColor: c }}
                            title={c}
                        />
                    ))}
                     <div className="relative w-10 h-10 rounded-full overflow-hidden border-2 border-ink-500 hover:border-gold-500 transition-colors">
                        <input 
                            type="color" 
                            value={color}
                            onChange={(e) => setColor(e.target.value)}
                            className="absolute inset-0 w-[150%] h-[150%] -top-1/4 -left-1/4 cursor-pointer p-0 border-0"
                        />
                        <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-ink-900 mix-blend-difference font-bold text-xs">
                            +
                        </div>
                     </div>
                </div>
            </div>
            
             <div className="flex justify-end">
                <button 
                    onClick={() => { setPosition({x:50, y:50}); setRotation(0); setScale(1); setColor('#000000'); }}
                    className="flex items-center gap-1 text-xs text-gold-500 hover:text-gold-400 transition-colors px-2 py-1 rounded hover:bg-ink-700"
                >
                    <RotateCcw size={12} /> Resetear valores
                </button>
            </div>
        </div>

        <Button onClick={handleSaveComposite} className="w-full max-w-md py-4 shadow-xl shadow-gold-500/10 text-lg">
            <Check size={22} /> Generar Previsualización
        </Button>
    </div>
  );
};